console.log("page loaded...");

function message() {
    alert("This game is supported on Linux");
}

var cartCount = 0;
var buySpan = document.querySelector("#buy");

function buy() {
    cartCount++;
    buySpan.innerText = cartCount;
}

var gameImg = document.querySelector("#cafe-neko")

function scrollGameleft() {
    gameImg.src = "cafe-neko.png";
}

function scrollGameright() {
    gameImg.src = "pixel-ninjas-2.png"
}

function scrollGameright() {
    gameImg.src = "pixel-ninjas-2.png"
}